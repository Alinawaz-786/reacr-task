import React from 'react'
import Feed from './Feed'

interface objectprops {
  posts: Array<
    {
      id?: number,
      title?: string,
      datetime?: string,
      body: string
    }
  >
}
const Home = ({ posts }: objectprops) => {
  return (
    <main>
      {posts.length ? (
        <Feed posts={posts} />
      ) : (
        <p style={{marginTop: "2rem"}}>
          No Post Record Exist
        </p> 
      )}
    </main>
  )
}

export default Home
