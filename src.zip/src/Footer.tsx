
function Footer() {
    return (
      <footer>
        <h2>Footer</h2>
      </footer>
    );
  }
  
  export default Footer;
  