import React from 'react'
import Post from './Post'

interface objectProps{
    posts: Array<{
        id?: number,
      title?: string,
      datetime?: string,
      body: string
    }>
}
const Feed = ({posts}:objectProps) => {
  return (
    <div>
      {posts.map(post =>(
        <Post key={post.id}  post={post}/>
      ))}
    </div>
  )
}

export default Feed
