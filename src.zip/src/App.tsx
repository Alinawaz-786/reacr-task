import Header from './Header';
import Nav from './Nav';
import Footer from './Footer';
import NewPost from './NewPost';
import PostPage from './PostPage';
import About from './About';
import Home from './Home';
import Missing from './Missing';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { format } from 'date-fns';
import api from './api/post';
import EditPost from './EditPost';
import { MyProvider }  from './context/DataContext'
// import {useState,useEffect} from 'react';

interface objectProps {
  id: number,
  title: string,
  datetime: string,
  body: string
}


function App() {
  const [post, setPost] = useState<Array<objectProps>>([]);
  const [filterPost, setFilterPost] = useState<Array<objectProps>>(post);

  const [search, setSearch] = useState<string>('');
  const [postBody, setPostBody] = useState('');
  const [postTitle, setPostTitle] = useState('');
  const [editBody, setEditBody] = useState('');
  const [editTitle, setEditTitle] = useState('');

  useEffect(() => {
    const fetchPost = async () => {
      try {
        const response = await api.get('/posts')
        if (response && response.data) {
          console.log(response.data);
          setPost(response.data)
          setFilterPost(response.data)

        }
      } catch (err) {
        // if(err.response){
        //   console.log(err.response.data);
        // }
      }
    }
    fetchPost();
  }, [])

  useEffect(() => {
    if (search === "") {
      setFilterPost(post)
    }
    const filterResult = post.filter(pos =>
      ((pos.body).toLowerCase()).includes(search.toLowerCase()) ||
      ((pos.title).toLowerCase()).includes(search.toLowerCase()))
    setFilterPost(filterResult);
  }, [post, search])

  const navigationHistory = useNavigate()

  const handleEdit = async (id: number) => {

    const dateTime = format(new Date(), 'MMMM dd, yyyy pp');
    const UpdatePost: any = { id, title: editTitle, datetime: dateTime, body: editBody };
    console.log("id,UpdatePost");
    console.log(id, UpdatePost);
    try {
      const response = await api.put(`/posts/${id}`, UpdatePost)
      setPost(post.map(item => item.id === id ? { ...response.data } : post))
      setEditBody('')
      setEditTitle('')
      navigationHistory('/home');
    } catch (error) {
      console.log(error)
    }
  }
  const handleSubmit = async (e: any) => {
    e.preventDefault()
    const id = post.length ? post[post.length - 1].id + 1 : 1;
    const dateTime = format(new Date(), 'MMMM dd, yyyy pp');
    const newPost: any = { id, title: postTitle, datetime: dateTime, body: postBody };
    try {
      const response = await api.post('/posts', newPost)
      setPost([...post, response.data]);
      setPostTitle('');
      setPostBody('');
      navigationHistory('/home');
    } catch (error) {
      console.log(error)
    }
  };


  const handleDelete = async (id: number) => {
    try {
      await api.delete(`/posts/${id}`);
      const PostList = post.filter(post => post.id !== id)
      setPost(PostList)
      navigationHistory('/home')
    } catch (error) {

    }

  };


  return (
    <MyProvider>
      <div className="App">
        <Nav search={search} setSearch={setSearch} />
        <Header />

        <>
          <Routes>
            <Route path="/home" element={<Home posts={filterPost} />} />
            <Route path="/about" element={<About />} />
            <Route path="/NewPost" element={<NewPost handleSubmit={handleSubmit} postTitle={postTitle} postBody={postBody} setPostTitle={setPostTitle} setPostBody={setPostBody} />} />
            <Route path="/edit-post/:id" element={<EditPost posts={filterPost} handleEdit={handleEdit} editTitle={editTitle} editBody={editBody} seteditTitle={setPostTitle} seteditBody={setPostBody} />} />
            <Route path="/post/:id" element={<PostPage posts={post} handleDelete={handleDelete} />} />
            <Route path="/Missing" element={<Missing />} />
          </Routes>
        </>
        <Footer />
      </div>
    </MyProvider>
  );
}

export default App;
