
function About() {
    return (
      <main>
        <h2>About</h2>
      </main>
    );
  }
  
  export default About;
  