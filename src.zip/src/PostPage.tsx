import { useParams, Link } from 'react-router-dom'

interface objectProps {
  posts: Array<{
    id: number,
    title: string,
    datetime: string,
    body: string
  }>,
  handleDelete: (e: any) => void
}


function PostPage({ posts, handleDelete }: objectProps) {
  const { id } = useParams();
  const post = posts.find(post => (post.id).toString() === id)
  return (
    <main>
      <h2>Post Page</h2>
      {post && 
        <>
        <h2>{post.title}</h2>
        <p>{post.datetime}</p>
        <p>{post.body}</p>
        <button onClick={() => handleDelete(post.id)}>
          Delete
        </button>

        <Link to={`/edit-post/${post.id}`}>Edit</Link>
        </>
      }
      {!post &&
      <>
        <h2>Post Not Found</h2>
        <Link to='/'> <p>Visit Our Home Page</p> </Link>
      </>

      }
    </main>
  );
}

export default PostPage;
