// import { createContext, useState, useEffect } from "react";

// type ContextProviderProp = {
//     tite: string,
// }

// const DataContext = createContext<any>(undefined)

// export const DataProvider = ({ children }: any) => {
//     const title = 'Navber Context testinf'
//     const value = {
//         title
//     }
//     return(
//         <DataContext.Provider value={{value}}>
//             {children}
//         </DataContext.Provider>
//     )
   
// }

// export default DataContext;
// MyContext.tsx
import React, { createContext, useContext,useState } from 'react';

type MyContextType = {
  data: string;
  updateData: (newData: string) => void;
};

const MyContext = createContext<MyContextType | undefined>(undefined);

export const MyProvider = ({ children }:any) => {
  const [data, setData] = useState<string>('Default Data');

  const updateData =  (newData: string) => {
    setData(newData);
};

  return (<MyContext.Provider value={{ data, updateData }}>{children}</MyContext.Provider>);
};

export const useMyContext = () => {
  const context = useContext(MyContext);
  if (!context) {
    throw new Error('useMyContext must be used within a MyProvider');
  }
  return context;
};
